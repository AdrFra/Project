public class ItemToPurchase {

    private String itemName;
    private double itemPrice;
    private int itemQuantity;
    private String itemDescription;

    //Constructor
    public ItemToPurchase(String itemName, double itemPrice, int itemQuantity, String itemDescription) {
        this.itemName = itemName;
        this.itemPrice = itemPrice;
        this.itemQuantity = itemQuantity;
        this.itemDescription = itemDescription;
    }

    //Default constructor
    public ItemToPurchase()
    {
        this.itemName = "";
        this.itemPrice = 0.00;
        this.itemQuantity = 0;
        this.itemDescription = "";
    }

    //mutators & accessors
    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public double getItemPrice() {
        return itemPrice;
    }

    public void setItemPrice(double itemPrice) {
        this.itemPrice = itemPrice;
    }

    public int getItemQuantity() {
        return itemQuantity;
    }

    public void setItemQuantity(int itemQuantity) {
        this.itemQuantity = itemQuantity;
    }

    public String getItemDescription() {
        return itemDescription;
    }

    public void setItemDescription(String itemDescription) {
        this.itemDescription = itemDescription;
    }


    // Outputs the item name followed by the quantity,
    //price, and subtotal (quantity x price)
    public void printItemCost(){

        System.out.println(this.getItemName() + " " +  this.getItemQuantity() + " @ " + this.getItemPrice() + " = ");
        System.out.println("$" + this.getItemQuantity() * this.getItemPrice() );
    }

    //Outputs the item name and description
    public void printItemDescription(){
        System.out.println(this.getItemDescription()  + ": " + this.getItemName());


    }

    //To string
    @Override
    public String toString() {
        return "ItemToPurchase{" +
                "itemName='" + itemName + '\'' +
                ", itemPrice=" + itemPrice +
                ", itemQuantity=" + itemQuantity +
                ", itemDescription='" + itemDescription + '\'' +
                '}';
    }
}
