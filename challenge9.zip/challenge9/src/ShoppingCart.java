
import java.util.ArrayList;
import java.util.Scanner;
//Creating object, build the ShoppingCart class with the following specifications.
public class ShoppingCart {
    private String customerName;
    private String currentDate;
    private static ArrayList<ItemToPurchase> cartItems;

//Default constructor
    public ShoppingCart() {
        this.customerName = "None";
        this.currentDate = "January 1, 2022";
        this.cartItems = new ArrayList<>();
    }

   //Parameterized constructor
    public ShoppingCart(String customerName, String currentDate) {
        this.customerName = customerName;
        this.currentDate = currentDate;
        this.cartItems = new ArrayList<>();
    }

//Getters
    public String getCustomerName() {
        return customerName;
    }



    public String getCurrentDate() {
        return currentDate;
    }











   //Adds anItem to cartItems arrayList. Does not return
   ////anything
    public static void addItem(ItemToPurchase anItem){

    cartItems.add(anItem);



    }

    //Removes item from cartItems arrayList that matches the
    ////itemName received as a parameter. Does not return
    ////anything.If item name cannot be found, print message: Item not
    ////found in cart. Nothing removed.
    public static void removeItem(String itemName){

            boolean removedItem = false;


            for (int i =0; i<cartItems.size();i++) {


                if (cartItems.get(i).getItemName().equals(itemName)) {

                    cartItems.remove(cartItems.get(i));
                    i--;
                    removedItem = true;

                } else System.out.println(itemName + " " + cartItems.get(i));

            }
            if (removedItem == false){

                System.out.println("Nothing removed");
            }





    }
//Modifies an item's quantity in the cartItem that matches the
////parameter, an Item, which contains only the productName
////and the productQuantity. Does not return anything.
//// If item can be found (by productName) in cart, use the
////quantity provided in the parameter to modify item in cart
    public static void modifyItem (ItemToPurchase anItem){

        for (int i = 0; i<cartItems.size();i++) {

            if (cartItems.get(i).equals(anItem)){

                cartItems.get(i).setItemQuantity(anItem.getItemQuantity());
            }
            System.out.println("Item not found in cart. Nothing modified");
        }

    }
    //Calculates and returns total quantity of all items in cart. Has
    //no parameters.
    public static int getNumItemsInCart(){
        int totalQuan = 0;
        for (int i =0;i<cartItems.size();i++){

            totalQuan = totalQuan + cartItems.get(i).getItemQuantity();

        }
        return totalQuan;

    }
    //Calculates and returns the total cost of items in cart. Has no
    //parameters.
    public static double getCostOfCart() {
        double cost = 0;
        for (int i = 0; i<cartItems.size(); i++){

            cost = cost + cartItems.get(i).getItemPrice();

        }

        return cost;
    }

    //Prints the name of the shopping cart, the date it was
    //created, the total items in the cart, and all the objects in
    //cart.
    // If cart is empty, output this message: SHOPPING CART IS
    //EMPTY
    public void printTotal(){


        if (!cartItems.isEmpty()) {

            System.out.println(customerName + " " +  currentDate);
            System.out.println("Number in cart: " + getNumItemsInCart());

            for (int i = 0; i<cartItems.size();i++){
                cartItems.get(i).printItemCost();

        }



        }else System.out.println("SHOPPING CART IS EMPTY");

    }

    //Prints the name of the shopping cart, the date it was
    //created, the literal “Item Descriptions”, and the name and
    //description of each object in cart.
    public void  printDescriptions(){


        for (int i = 0; i<cartItems.size(); i++){

            System.out.println(cartItems.get(i).getItemName() + cartItems.get(i).getItemDescription());

        }


    }



}
