/**
 * @author pather ID 6348679
 *
 * Title: Fun with Strings
 *
 * 
 * Name:                Adrian Franquin
 *
 * Description of program's functionality:this program will create
 * a class called FunWithStrings that has a main method which calls
 * 10 methods, one for every problem. From method 1-9 the user will
 * give one input of the class "String".Method 10 will not have any
 * input and will just generate a rundom number.
 *
 */
import java.util.Scanner;
import java.util.Random;
public class funWithStrings {
    public static Scanner keyboard = new Scanner(System.in);
    public static void main (String[] args){

        System.out.println("Enter a word");
        String aWord = keyboard.nextLine();

        problem1(aWord);
        problem2(aWord);
        problem3(aWord);
        problem4(aWord);
        problem5(aWord);
        problem6(aWord);
        problem7(aWord);
        problem8(aWord);
        problem9(aWord);
        problem10();

    }

    /**
     * This Method uses the String input to get the length of the
     * String parameter and store it in a variable.
     *
     * @param aWord
     */
    public static void problem1(String aWord){


        System.out.println("The length of the String " + aWord + "is " + aWord.length());
    }

    /**
     * This Method uses the String input to get
     * the location of the second ‘i’ in the word,
     * @param aWord
     */
    public static void problem2(String aWord){
        int firstO = aWord.indexOf("i");
        int setLoc = aWord.indexOf("i", (firstO + 1));
        System.out.println("The second i in" + aWord + "is located at position" + setLoc);



    }

    /**
     *This Method uses the String input to get
     * the first ‘e’ in the word and write what
     * is the position for this letter.
     */

    public static void problem3(String aWord){
        int firstLoc = aWord.indexOf("e");
        System.out.println("The first e in " + aWord + "is located at position" + firstLoc);


    }

    /**
     *This Method uses the String input to get the
     * character in the middle of the parameter.
     * @param aWord
     */
    public static void problem4(String aWord){
        int charMid = aWord.length()/2;
        System.out.println("The character in the middle of " + aWord + " is " + aWord.charAt(charMid));


    }

    /**
     *This Method uses the String input to get the first
     * half of the parameter, from the beginning to the middle
     * @param aWord
     */
    public static void problem5(String aWord){
        int firstHalfIndex = aWord.length()/2;
        String firstHalf = aWord.substring(0, firstHalfIndex);
        System.out.println("The first half of the " + aWord + " is " + firstHalf);



    }

    /**
     *This Method uses the String input to get the second
     * half of the parameter, from the middle to the end of the
     * parameter
     * @param aWord
     */
    public static void problem6(String aWord){
        int indexMid = aWord.length()/2;
        String secondHalfWord = aWord.substring(indexMid);
        System.out.println("The second part of the " + aWord + " is " + secondHalfWord);


    }

    /**
     *This Method uses the String input to will
     * switch the 2 halves of the word
     * @param aWord
     */
    public static void problem7(String aWord){
        int firstHalfIndex = aWord.length()/2;
        String firstHalf = aWord.substring(0, firstHalfIndex);
        int indexMid = aWord.length()/2;
        String secondHalfWord = aWord.substring(indexMid);

        System.out.println("Switched halves for a word: " + aWord + " is: " + secondHalfWord + firstHalf);



    }

    /**
     *This Method uses the String input to turn
     * the entire parameter into all uppercase
     * @param aWord
     */
    public static void problem8(String aWord){
        String aWordUp = aWord.toUpperCase();
        System.out.println("The " + aWord + " in upper case is " + aWordUp);


    }

    /**
     *This Method uses the String input to square
     * the length of the parameter, and then generate
     * a random number between 1 and the squared length.
     * @param aWord
     */
    public static void problem9(String aWord){
        int aWordL = aWord.length();
        double aWordSqrt = Math.sqrt(aWordL);
        Random rand = new Random();
        double random_number = (1 + rand.nextDouble() * aWordSqrt);

        System.out.println("The square of the length of " + aWord + " is " + aWordSqrt +
                " and a random number between 1 and " + aWordSqrt + " is " + random_number);





    }

    /**
     *This Method will generate a random number between 1 and 100.
     */
    public static void problem10(){
        Random rand = new Random();
        int random_number = rand.nextInt(100)+1;
        System.out.println("Congratulations, you just won $" + random_number + "! You can go out and treat yourself to a nice dinner!");


    }

}
