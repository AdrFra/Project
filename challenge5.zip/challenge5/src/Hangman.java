import java.util.Random;
//Defining private variables.
public class Hangman {
    private String secretWord;

    private String userGuess;

//Make a constructor with 5 different words with a switcher statement.
    public Hangman() {
        Random aRandom = new Random();
        int randomGen = aRandom.nextInt(1,6);


        switch (randomGen){
            case 1: secretWord ="climb";
            userGuess = "_____";
            break;
            case 2: secretWord = "state";
            userGuess = "_____";
            break;
            case 3: secretWord = "went";
            userGuess = "____";
            break;
            case 4: secretWord = "computer";
            userGuess = "________";
            break;

            default: secretWord = "program";
            userGuess = "_______";


        }



    }
//Defining getters and setters.
    public String getSecretWord() {
        return secretWord;
    }

    public void setSecretWord(String secretWord) {
        this.secretWord = secretWord;
    }
    //Defining getters and setters.
    public String getUserGuess() {
        return userGuess;
    }

    public void setUserGuess(String userGuess) {
        this.userGuess = userGuess;
    }
//To string method.
    @Override
    public String toString() {
        return "The word was" + secretWord +  "and you guessed" + userGuess;
    }
}
