/**
 * @author pather ID 6348679
 *
 * Title: Challenge 5
 *
 * Semester:            COP 2210, Fall 2023
 * Proffesor's name:    Prof. Charters
 * Name:                Adrian Franquin
 * Description of program's functionality:this program will store
 * 5 different word that user will have to guess.The program will
 * ask the user to guess 1 letter at  a time. If the user guessed
 * the word program will ask them if they want to play again.
 */

import javax.print.MultiDocPrintService;
import java.util.Scanner;
//This method will drive the program in a loop with a while condition.
//If the user wants to play again and input true, the loop will start over.
public class PlayGame {
    public static int gamesWon = 0;
    public static int gamesLost= 0;
    public static Scanner scnr = new Scanner(System.in);
    public static void main(String[] args) {



                boolean playAgain = true;
        do{
            Hangman aGame = new Hangman();

            processGuesses(aGame);
            determineWinner(aGame);

            System.out.println("Play again? (True or False?)");
            playAgain = scnr.nextBoolean();


        }while(playAgain);

        summarize();


    }
//This method is responsible for process the game itself.
    //It will take a word from a class and determine how
// many attempts the user has based on the length of that word
    //It will then get an input form the user.
    public static void processGuesses(Hangman aGame){
        int secretWordLength = aGame.getSecretWord().length();
        int chances = 3 * secretWordLength;
        int usedChances = 0;
        int loc = -1;
        String userGuess = "";

        while (usedChances < chances && !(aGame.getSecretWord().equalsIgnoreCase(aGame.getUserGuess())))
        {
            usedChances = usedChances + 1;
            System.out.println("Tell me a letter to guess");
            char userGuessLetter = scnr.nextLine().toLowerCase().charAt(0);

            loc = -1;

            do {
                loc ++;
                loc = aGame.getSecretWord().indexOf(userGuessLetter, loc);
                if (loc != -1){
                    String part1 = aGame.getUserGuess().substring(0,loc);
                            String part2 = aGame.getUserGuess().substring(loc + 1);
                    userGuess = part1 + userGuessLetter + part2;
                    aGame.setUserGuess(userGuess);
                }
            } while (loc >= 0);
            System.out.println(aGame.getUserGuess());

        }


        if (!(aGame.getSecretWord().equalsIgnoreCase(aGame.getUserGuess()))){

            System.out.println("Enter guess for the entire word.");
            userGuess = scnr.nextLine();
            aGame.setUserGuess(userGuess);

        }

    }





//This method is responsible for determining if the user guessed the word
    //within the given attempts and determine if the won or not.
    //If the user won, the method will add 1 to gameWon.
    //If the user lost, the method will 2 to gameLost.
    public static void determineWinner(Hangman aGame){



        if (aGame.getSecretWord().equalsIgnoreCase(aGame.getUserGuess())){

            System.out.println("Congrats!You guessed the secret word");
            gamesWon = gamesWon + 1;
        }
        else {
            System.out.println("You have one last time to guess the word");
            String userGuess1 = scnr.nextLine();
            aGame.setUserGuess(userGuess1); //FIXME
            if (aGame.getSecretWord().equalsIgnoreCase(aGame.getUserGuess())) {
                System.out.println("Congrats!You guessed the secret word");
                gamesWon = gamesWon + 1;
            } else
                System.out.println("You lost");
            gamesLost = gamesLost + 1;
        }
    }

//This last method will just store the amount of games
// lost and won and then display it at the end.
    public static void summarize (){
        System.out.println("You wont " + gamesWon + " games");
        System.out.println("You lost " + gamesLost + " games");

    }
}
