/**
 @author pather ID 6348679

 Title:BMI
 

 Name:Adrian Franquin
 Description of program's functionality:this program will get inputs for 4 things from the
 user which will be: Name, Last Name, their weight and Height.Will take all these variables
 and will calculate there BMI based on theire inputs. After the program will calculate the BMI
 it will shw it to the user telling them if there are Underweight/Helathy/Overweight/Obese/Extremely obese
 based on the BMI number.
 */

import java.util.Scanner;
public class BMIHealth {

    //The main will call createPerson method assigning it to the aPerson.
    // It will then pass aPerson to showBMi method.
    public static void main(String[] args) {


        Person aPerson = createPersonObject();
        showBMI(aPerson);
    }
//This method asks the user for the input for there variables to
    //get the information about their Name, Last Name, their weight and Height.
    //It will then assign all these information to the person object.
    public static Person createPersonObject(){

        String firstName, lastName;
        double height;
        double weight;

        Scanner keyboard = new Scanner(System.in);

        System.out.println("What is your last name?");
        lastName = keyboard.nextLine();
        System.out.println("Whats is your first name?");
        firstName = keyboard.nextLine();
        System.out.println("What is your height in inches?");
        height = keyboard.nextDouble();
        System.out.println("What is your weight in pounds?");
        weight = keyboard.nextDouble();

        Person anyPerson = new Person(lastName, firstName, height, weight);
        return anyPerson;

    }

    //This method will take all the information and will calculate BMI based on the numbers the user input
    //If the user's BMi is not healthy the program will tell the user which number is a healthy BMI.
    public static void showBMI(Person aPerson){
        System.out.println(aPerson);
        double aBMI = aPerson.calculateBMI();
        System.out.printf("Your BMI is %.2f",aBMI);
        System.out.println(" ");

        String health = aPerson.determineHealth(aBMI);
        System.out.println("Based on the BMI calculations, you are " + health);

        if (health != "Healthy") {
            double rec = aPerson.recommendedWeight();
            System.out.printf("Recommended weight for your BMI to be healthy is %.2f pounds", rec);


        }



    }
}
