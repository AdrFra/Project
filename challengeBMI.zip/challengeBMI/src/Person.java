//This is an object class. We will define the
// object here using private variables.
public class Person {
    private String lastName;
    private String firstName;
    private double heightInches;
    private double weightPounds;


   //This is the constructor for our object.
    public Person(String lastName, String firstName, double heightInches, double weightPounds) {
        this.lastName = lastName;
        this.firstName = firstName;
        this.heightInches = heightInches;
        this.weightPounds = weightPounds;
    }


//These will be our getters and setter for the object.
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public double getHeightInches() {
        return heightInches;
    }

    public void setHeightInches(double heightInches) {
        this.heightInches = heightInches;
    }

    public double getWeightPounds() {
        return weightPounds;
    }

    public void setWeightPounds(double weightPounds) {
        this.weightPounds = weightPounds;
    }

    @Override
    //This is toString method for the object.
    public String toString() {
        return "Person: " +
                "lastName = " + lastName + ", firstName = " + firstName + "" +
                ", heightInches = " + heightInches + ", weightPounds = " + weightPounds ;
    }

    //This method will calculate recommended weight for healthy BMI.
    public double recommendedWeight(){
        double optimumWeight=0;

        optimumWeight = (25 * Math.pow(heightInches, 2))/703;

        return optimumWeight;

    }

   //This method will calculate BMI.
    public double calculateBMI(){

        double BMI = 0;
        BMI= (weightPounds / ((heightInches) * (heightInches))) * 703;

        return BMI;

    }

    //This method will determine if the user's BMI is healthy or not.
    public String determineHealth(double aBMI){

        String healthStatus ="";

        if (aBMI<18.5){
            healthStatus ="Underweight";
        }
        else if(aBMI >= 18.5 && aBMI < 25){
            healthStatus ="Healthy";
        }
        else if (aBMI >= 25 && aBMI < 30){
            healthStatus ="Overweight";
        }
        else if (aBMI > 30 && aBMI <=39.9){
            healthStatus ="Obese";
        }
        else if (aBMI > 39.9){
            healthStatus = "Extremely obese";
        }


        return healthStatus;

    }


}
