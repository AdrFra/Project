//This entire block of code is responsible for creating a class Student.
public class Student {
    // first name, last name, panther id, gpa

    private String firstName;
    private String lastName;
    private int id;
    private double gpa;


    //Constructor for the Student class
    public Student(String firstName, String lastName, int id, double gpa) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.id = id;
        this.gpa = gpa;
    }

   //The following are getters and setters for the Student class
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getGpa() {
        return gpa;
    }

    public void setGpa(double gpa) {
        this.gpa = gpa;
    }

    @Override
    //To string method for a Student class
    public String toString() {
        return  firstName + " " + lastName + "\n Student's ID: " + id + " \nStudent's gpa: " + gpa;
    }
}
