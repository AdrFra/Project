/**
 * @author
 *
 * Title: Array of Students
 *
 * Semester:            COP 2210, Fall 2023
 * Proffesor's name:    Prof. Charters
 * Name:               ALbert
 * Description of program's functionality:this program will ask the user for the input
 * for the selected amount of students (user can choose) and then based on the input
 * which will include their name, last name and their gpa, the program will calnulate the
 * average gpa between those student, the student who got the highest gpa and the student with
 * the lowest gpa as well as a student who has the higest gpa among all students.
 *
 */

//import java.util.Scanner;
//public class FIURegistrar {
//    public static Scanner input = new Scanner(System.in);
//
//
//   // The main will call two methods. ! method will be assigned to array.
//    //And then the set array will be passed to the second method.
//    public static void main(String[] args) {
//
//
//
//
//
//        Student [] students = createArrayOfStudents();
//
//        processArrayOfStudents(students);
//
//
//    }
//
//   //This method ask the user for the amount of students they want
//    //And then ask the set information for each student
//    //After which the method will return numArray.
//    public static Student[] createArrayOfStudents (){
//
//        System.out.println("Enter the amount of students");
//        int numStudent = input.nextInt();
//        Student [] numArray = new Student[numStudent];
//        input.nextLine();
//
//        for (int i = 0;i<numStudent;i++){
//            System.out.println("What is the name for the student");
//            String fName = input.nextLine();
//            System.out.println("What is the last name for the student");
//            String lName = input.nextLine();
//            System.out.println("What is the ID for the student");
//            int ID = input.nextInt();
//            System.out.println("What is the GPA for the student");
//            double gpa = input.nextDouble();
//            input.nextLine();
//            Student student = new Student(fName,lName,ID,gpa);
//            numArray [i] = student;
//
//        }
//
//
//
//
//        return numArray;
//    }
//
//    //This method will get the array of student which was created in the previos method
//    // and will use this information in  order to calculate the average gpa between those
//    // student, the student who got the highest gpa and the student with
//    // the lowest gpa as well as a student who has the highest gpa among all students.
//    public static void processArrayOfStudents(Student[] numArray){
//
//        int lowest;
//        int sum;
//        int avg;
//        double sum1 = 0;
//        int counter = 0;
//        double average;
//
//        double  highestValue = numArray[0].getGpa();
//        double  lowestValue = numArray[0].getGpa();
//        int studentWithHighest = 0;
//        int studentWithLowest = 0;
//
//        for (int i =numArray.length-1;i>=0;i-- ){
//
//            if (numArray[i].getGpa() > highestValue){
//                highestValue = numArray[i].getGpa();
//                studentWithHighest = i;
//
//
//            }
//
//            if (numArray[i].getGpa() < lowestValue){
//                lowestValue = numArray[i].getGpa();
//                studentWithLowest = i;
//        }
//            sum1 += numArray[i].getGpa();
//            counter++;
//
//        }
//
//
//        average = (double)sum1/counter;
//
//        System.out.println("Student with highest GPA is " + numArray[studentWithHighest]);
//        System.out.println("Student with lowest GPA is " + numArray[studentWithLowest]);
//        System.out.println("The average gpa is " + average);
//
//        System.out.println("Students that have an above average gpa: ");
//
//        for (int i = 0;i<numArray.length;i++){
//
//            if (numArray[i].getGpa()>average){
//                System.out.println(numArray[i]);
//            }
//        }
//
//    }
//}
