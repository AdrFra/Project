/**
 * By Adrian Franquin
 * Date: November 22
 * Description: modify createArrayOfStudents to
 * read from a file instead of a user input.
 * Modify the  processArrayOfStudents method to
 * write output onto a text file named studentReport.txt
 */

import java.io.IOException;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.File;
public class FIURegister {
        public static Scanner input = new Scanner(System.in);


        // The main will call two methods. ! method will be assigned to array.
        //And then the set array will be passed to the second method.
        public static void main(String[] args)  throws IOException
        {



            Student [] students = createArrayOfStudents();

            processArrayOfStudents(students);


        }

        //This method ask the user for the amount of students they want
        //And then ask the set information for each student
        //After which the method will return numArray.
        public static Student[] createArrayOfStudents () throws IOException
        {

//            System.out.println("Enter the amount of students");
            //int numStudent = input.nextInt();
//            Student [] numArray = new Student[numStudent];
//            input.nextLine();

            Student[] numArray = new Student[countRecords()];
            File aFile = new File("students.txt");
            Scanner inFile = new Scanner(aFile); //Opens file
            String lastName, firstName;
            int pantherID;
            double GPA;
            int i = 0;


            while (inFile.hasNext()) {
                lastName = inFile.next();
                firstName = inFile.next();
                pantherID = inFile.nextInt();
                GPA = inFile.nextDouble();

                numArray [i] = new Student (firstName, lastName, pantherID, GPA);
                i++;


            }
            inFile.close();
            return numArray;






            //for (int i = 0;i<countRecords();i++){

                /**
                 * This code is replaced bi files
                 * System.out.println("What is the name for the student");
                 *  String fName = input.nextLine();
                 * System.out.println("What is the last name for the student");
                 * String lName = input.nextLine();
                 * System.out.println("What is the ID for the student");
                 * int ID = input.nextInt();
                 * System.out.println("What is the GPA for the student");
                 * double gpa = input.nextDouble();
                 * input.nextLine();
                 * Student student = new Student(fName,lName,ID,gpa);
                 * numArray [i] = student;
                  */

            }




            //return numArray;


        public static int countRecords() throws IOException
        {
            int counter = 0;
            File aFile = new File("students.txt");
            Scanner inFIle = new Scanner(aFile); //Opens a file
            while (inFIle.hasNext()){

                counter++;
                inFIle.nextLine();
            }
            inFIle.close();

            return counter;


        }

        //This method will get the array of student which was created in the previos method
        // and will use this information in  order to calculate the average gpa between those
        // student, the student who got the highest gpa and the student with
        // the lowest gpa as well as a student who has the highest gpa among all students.
        public static void processArrayOfStudents(Student[] numArray) throws IOException
        {

            int lowest;
            int sum;
            int avg;
            double sum1 = 0;
            int counter = 0;
            double average;

            double  highestValue = numArray[0].getGpa();
            double  lowestValue = numArray[0].getGpa();
            int studentWithHighest = 0;
            int studentWithLowest = 0;

            for (int i =numArray.length-1;i>=0;i-- ){

                if (numArray[i].getGpa() > highestValue){
                    highestValue = numArray[i].getGpa();
                    studentWithHighest = i;


                }

                if (numArray[i].getGpa() < lowestValue){
                    lowestValue = numArray[i].getGpa();
                    studentWithLowest = i;
                }
                sum1 += numArray[i].getGpa();
                counter++;

            }


            average = (double)sum1/counter;

            System.out.println("Student with highest GPA is " + numArray[studentWithHighest]);
            System.out.println("Student with lowest GPA is " + numArray[studentWithLowest]);
            System.out.println("The average gpa is " + average);

            System.out.println("Students that have an above average gpa: ");

            for (int i = 0;i<numArray.length;i++){

                if (numArray[i].getGpa()>average){
                    System.out.println(numArray[i]);
                }
            }

           //Create file and put everything there.
            FileWriter fw = new FileWriter("studentReport.txt", true);
            PrintWriter pw = new PrintWriter(fw); //Open for output
            pw.println("\nThe student with the highest GPA is " + numArray[studentWithHighest]);
            pw.println("\nThe student with the lowest GPA is " + numArray[studentWithLowest]);
            pw.println("\nThe average GPA for all students is " + average);
            pw.close();

        }
    }

