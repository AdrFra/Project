/**
 * @author pather ID 6348679
 *
 * Title: Mega Millions (Arrays)
 *
 * Semester:            COP 2210, Fall 2023
 * Proffesor's name:    Prof. Charters
 * Name:                Adrian Franquin
 * Description of program's functionality:this program will
 * simulate a person buying a MegaMillions lottery ticket, and
 * then checking to see if his/her numbers match the 5 winning
 * lotto numbers plus the power ball number.  The driver class
 * will display the appropriate messages concerning the winnings(or not!)
 */



public class LotteryGame {

    public static void main(String[] args)
    {
        MegaMillionsLotto myGame = new MegaMillionsLotto();
        myGame.getUserPicks();
        int matchingNums = myGame.checkLotteryMatch();
        int userPowerBall = myGame.getUserPowerBall();
        int winningPowerBall = myGame.getWinningPowerBall();

        switch (matchingNums){
            case 3:
                if (userPowerBall == winningPowerBall){
                System.out.println("Congrats you won 50$");}
                else System.out.println("Free ticket");
                break;
            case 4:
                if (userPowerBall == winningPowerBall){
                    System.out.println("Congrats you won 1000$");}
                else System.out.println("Congrats you won 100$");
                break;
            case 5:
                if (userPowerBall == winningPowerBall){
                    System.out.println("Congrats you won 5000$");}
                else System.out.println("Congrats you won 500$");
                break;
            case 6:
                if (userPowerBall == winningPowerBall){
                    System.out.println("Congrats you won 10000$");}
                else System.out.println("Congrats you won 1000$");
                break;
            case 7:
                System.out.println("Congrats you won 500,000$");
            default:
                System.out.println("Sorry, no prizes today. Try again!");
        }



    }
}
