
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

//Defining private classes to make an object
public class MegaMillionsLotto {
    private int[] winningMegaMillionsLottoNums;
    private int[] userLotteryPicks;
    private int winningPowerBall;
    private int userPowerBall;


    //This method will create random numbers for 1 to 71 and will check for duplicates
    //using a for loop. At the same time this random numbers will be store in the array.
    public MegaMillionsLotto()
    {
        Random random = new Random();
        int ranNum;
        boolean duplicatesExist = false;

        winningMegaMillionsLottoNums = new int[7];

        for (int i = 0; i<winningMegaMillionsLottoNums.length;i++){
            do {ranNum = random.nextInt(1,71);

            } while (checkForDuplicates(winningMegaMillionsLottoNums,ranNum));

            winningMegaMillionsLottoNums[i] = ranNum;
        }
        winningPowerBall = random.nextInt(1,26);


        //Create a loop that will:
        //1. generate a random num 1 - 70
        //2. loop to make sure the number is not duplicate in array
        //3. add number to winningMegaMillionsLottoNums[]
        //4.  After all 7 numbers are generated,
        //    generate a power ball number randomly between 1 - 25.

    }

   //This method will simply check for the duplicates in the array and a random numbers.
    public boolean checkForDuplicates(int[] anArray, int aNum)
    {
        boolean duplicatesFound = false;

        for (int x:anArray) {
            if (x == aNum) {
                return true;
            }
        }

        return duplicatesFound;
    }

    //This method will get the user input 7 times to get the number form 1 to 70 from the user.
    //It will also will have a validation loop to make sure there is no duplicates and a number
    // is between 1 and 70. The method will also ask for the powerball number between 1 and 25.
    public void getUserPicks()
    {
        System.out.println(toString());
        Scanner input = new Scanner(System.in);
        int userNum = 0;
        userLotteryPicks = new int[7];
        for (int i =0; i<7; i++){

            System.out.println("Enter a number between 1 and 70");
            userNum = input.nextInt();

            while (!(userNum>=1 && userNum<=70) || (checkForDuplicates(userLotteryPicks,userNum))) {
                System.out.println("Invalid input. Pick a number between 1 and 70");
                userNum = input.nextInt();

            }

            userLotteryPicks[i] = userNum;
        }

        System.out.println("Enter your powerball number");
        userPowerBall = input.nextInt();

        while (!(userPowerBall>=1 && userPowerBall<25)) {
            System.out.println("Invalid input. Pick a number between 1 and 25");
            userPowerBall = input.nextInt();
        }

        //1. Loop to ask user for 7 numbers between1 - 70
        //2. Validation loop that:
        //    a. Checks that the user enters a number between 1 - 70
        //    b. Checks for duplicates for the user's pick
        //3.  add the user's number to the userLotteryPicks
        //4.  Do a validation loop to Get user's power ball pick 1 - 25

    }

    //Outer For-loop that goes through every number in the winningMegaMillionsLottoNums[]
    //Nested Inner Loop checks each number in the userLotteryPicks,
    //to see if it matches the specific number in the winningMegaMillionsLottoNums[]
    //& if so, it adds to a counter
    //At end of outerloop, return counter
    public int checkLotteryMatch()
    {
        int counter = 0;

        for (int i = 0;i<7;i++){
            for (int j = 0;j<7;j++){
                if (winningMegaMillionsLottoNums[i] == userLotteryPicks[j]){
                    counter++;

                }
            }


        }

        return counter;
    }




    //Getters and setters
    public int[] getWinningMegaMillionsLottoNums() {
        return winningMegaMillionsLottoNums;
    }

    public void setWinningMegaMillionsLottoNums(int[] winningMegaMillionsLottoNums) {
        this.winningMegaMillionsLottoNums = winningMegaMillionsLottoNums;
    }

    public int[] getUserLotteryPicks() {
        return userLotteryPicks;
    }

    public void setUserLotteryPicks(int[] userLotteryPicks) {
        this.userLotteryPicks = userLotteryPicks;
    }

    public int getWinningPowerBall() {
        return winningPowerBall;
    }

    public void setWinningPowerBall(int winningPowerBall) {
        this.winningPowerBall = winningPowerBall;
    }

    public int getUserPowerBall() {
        return userPowerBall;
    }

    public void setUserPowerBall(int userPowerBall) {
        this.userPowerBall = userPowerBall;
    }

    //To string method.
    @Override
    public String toString() {
        return "MegaMillionsLotto{" +
                "winningMegaMillionsLottoNums=" + Arrays.toString(winningMegaMillionsLottoNums) +
                ", userLotteryPicks=" + Arrays.toString(userLotteryPicks) +
                ", winningPowerBall=" + winningPowerBall +
                ", userPowerBall=" + userPowerBall +
                '}';
    }


}
