/**
 * @author pather ID 6348679
 *
 * Title:Calories consumed and burned
 *
 * Description of program's functionality:
 * This program asks the user for how many calories the user conxumes and burns over the course of
 * a week, then display the average amount consumed and burned, as well as the net weekly calories.
 */
import javax.crypto.spec.PSource;
import java.util.Scanner;
public class Challenge1Franquin {

    public static int day1CalConsumed, day1CalBurned;
    public static int day2CalConsumed, day2CalBurned;
    public static int day3CalConsumed, day3CalBurned;
    public static int day4CalConsumed, day4CalBurned;
    public static int day5CalConsumed, day5CalBurned;
    public static int day6CalConsumed, day6CalBurned;
    public static int day7CalConsumed, day7CalBurned;

    public static int totalCaloriesConsumed;
    public static int totalCaloriesBurned;

    public static double averageCaloriesConsumed, averageCaloriesBurned;

    public static double netWeeklyPounds;

    public static void main (String[] args){
        getUserInput();
        calculateCalories();
        displayCalories();



    }

    /**
     *Asks the user for the calories consumed and burned for day 1-7.
     */
    public static void getUserInput(){
        Scanner scnr = new Scanner(System.in);

        System.out.println("Enter calories consumed for day #1:");
        day1CalConsumed = scnr.nextInt();

        System.out.println("Enter calories burned for day #1:");
        day1CalBurned = scnr.nextInt();




        System.out.println("Enter calories consumed for day #2:");
        day2CalConsumed = scnr.nextInt();

        System.out.println("Enter calories burned for day #2:");
        day2CalBurned = scnr.nextInt();




        System.out.println("Enter calories consumed for day #3:");
        day3CalConsumed = scnr.nextInt();

        System.out.println("Enter calories burned for day #3:");
        day3CalBurned = scnr.nextInt();




        System.out.println("Enter calories consumed for day #4:");
        day4CalConsumed = scnr.nextInt();

        System.out.println("Enter calories burned for day #4:");
        day4CalBurned = scnr.nextInt();




        System.out.println("Enter calories consumed for day #5:");
        day5CalConsumed = scnr.nextInt();

        System.out.println("Enter calories burned for day #5:");
        day5CalBurned = scnr.nextInt();




        System.out.println("Enter calories consumed for day #6:");
        day6CalConsumed = scnr.nextInt();

        System.out.println("Enter calories burned for day #6:");
        day6CalBurned = scnr.nextInt();




        System.out.println("Enter calories consumed for day #7:");
        day7CalConsumed = scnr.nextInt();

        System.out.println("Enter calories burned for day #7:");
        day7CalBurned = scnr.nextInt();




    }

    /**
     *Calculates calories for total calories consumed and burned.
     * Calculates average consumed and burned calories.
     * Calculates net weakly pounds.
     */
    public static void calculateCalories(){



        totalCaloriesConsumed = (day1CalConsumed + day2CalConsumed + day3CalConsumed +
                day4CalConsumed + day5CalConsumed + day6CalConsumed + day7CalConsumed);


        totalCaloriesBurned = (day1CalBurned + day2CalBurned + day3CalBurned +
                day4CalBurned + day5CalBurned + day6CalBurned + day7CalBurned);


        averageCaloriesConsumed = (double)(day1CalConsumed + day2CalConsumed + day3CalConsumed +
                day4CalConsumed + day5CalConsumed + day6CalConsumed + day7CalConsumed)/7;


        averageCaloriesBurned = (double)(day1CalBurned + day2CalBurned + day3CalBurned +
                day4CalBurned + day5CalBurned + day6CalBurned + day7CalBurned)/7;


        netWeeklyPounds = (double) (totalCaloriesConsumed - totalCaloriesBurned) / 3000.0;




    }

    /**
     * Displays total calories consumed/burned, as well as
     * average calories consumed/burned and ney weekly pound
     * for a week.
     */
    public static void displayCalories() {

        System.out.print("Total Calories Consumed this week are: ");
        System.out.printf("%,d\n", totalCaloriesConsumed);


        System.out.print("Total Calories Burned this week are: ");
        System.out.printf("%,d\n", totalCaloriesBurned);


        System.out.print("Average calories consumed are: ");
        System.out.printf("%,.2f\n", averageCaloriesConsumed);


        System.out.print("Average calories burned are: ");
        System.out.printf("%,.2f\n", averageCaloriesBurned);


        System.out.print("Net weekly pounds are: ");
        System.out.printf("%,.3f\n",netWeeklyPounds);









    }
}

