/**
 * @author pather ID 6348679
 *
 * Title: FIZZ/BUZZ
 *
 * 
 * Name:                Adrian Franquin
 * Description of program's functionality:this program will get numbers
 * from 1-100 and based on the number using an if statements will produce
 * an output. If the number is divisible by 3 and 5 with no remainder then
 * the number is "fizz buzz", if the number is divisible by 3 with no remainder
 * then it is a "fizz" and if it's divisible ny 5 with no remainder it is "buzz".
 *
 */

public class driver {
    //main will just call fizzBuzz method.
    public static void main(String[] args) {

        fizzBuzz();
    }

    //This method will produce different output based on the number.
    //If the number is divisible by 3 and 5 with no remainder then
    // * the number is "fizz buzz", if the number is divisible by 3 with no remainder
    // * then it is a "fizz" and if it's divisible ny 5 with no remainder it is "buzz".
    public static void fizzBuzz(){
        int i = 0;

        for (i=1;i<=100;i++){
            if (i%3==0 && i%5==0){
                int answer = (int) Math.pow((i/3+i/5),2);
                System.out.println("fizz buzz " + answer );
            }
            else if (i%3==0){
                System.out.println("fizz");
            }
            else if (i%5==0){
                System.out.println("buzz");
            }
            else System.out.println(i);

        }


    }
}
